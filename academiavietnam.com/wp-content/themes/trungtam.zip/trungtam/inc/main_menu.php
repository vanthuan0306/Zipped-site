 <?php
 add_theme_support( 'menus' );

register_nav_menus( 
	array (
 			'footer-nav-1' => 'Menu chân trang 1',
 			'footer-nav-2' => 'Menu chân trang 2',
 			'footer-nav-3' => 'Menu chân trang 3',
 			'footer-nav-4' => 'Menu chân trang 4',
 			) );
 			?>