<!-- Sidebar Widgets Column -->
<div class="col-md-4 col-xs-4">
  
  <?php dynamic_sidebar('sidebar-mini'); ?>

  
</div>